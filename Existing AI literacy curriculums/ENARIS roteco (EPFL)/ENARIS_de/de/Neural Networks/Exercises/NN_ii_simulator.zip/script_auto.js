//https://pietschsoft.com/post/2015/09/05/javascript-basics-how-to-create-a-dictionary-with-keyvalue-pairs
//var numericArray = [1, 2, 3, 4];
var dict = new Object();
dict["sq1"] = -1;
dict["sq2"] = -1;
dict["sq3"] = -1;
dict["sq4"] = -1;

function sig(val){
	if (val > 1) return 1;
	if (val < -1) return -1;
	return val;
}

function relu(val){
	if (val < 0) return 0;
	return val;
}

function propagate(){
   dict["wc1"] = dict["sq1"];
   dict["wc2"] = dict["sq2"];
   dict["wc3"] = dict["sq3"];
   dict["wc4"] = dict["sq4"];
   //---
   dict["sig1"] = sig(dict["wc1"] + dict["wc4"]);
   dict["sig2"] = sig(dict["wc2"] + dict["wc3"]);
   dict["sig3"] = sig(dict["wc1"] - dict["wc4"]);
   dict["sig4"] = sig(dict["wc2"] - dict["wc3"]);
   //---
   dict["sig5"] = sig(dict["sig1"] + dict["sig2"]);
   dict["sig6"] = sig(-dict["sig1"] + dict["sig2"]);
   dict["sig7"] = sig(dict["sig3"] - dict["sig4"]);
   dict["sig8"] = sig(dict["sig3"] + dict["sig4"]);
   //---
   dict["relu1"] = relu(dict["sig5"]);
   dict["relu2"] = relu(-dict["sig5"]);
   dict["relu3"] = relu(dict["sig6"]);
   dict["relu4"] = relu(-dict["sig6"]);
   dict["relu5"] = relu(dict["sig7"]);
   dict["relu6"] = relu(-dict["sig7"]);
   dict["relu7"] = relu(dict["sig8"]);
   dict["relu8"] = relu(-dict["sig8"]);
   //---
   dict["output1"] = dict["relu1"] + dict["relu2"]
   dict["output2"] = dict["relu3"] + dict["relu4"]
   dict["output3"] = dict["relu5"] + dict["relu6"]
   dict["output4"] = dict["relu7"] + dict["relu8"]
   //-- 
   //show_dict_short();
   //console.log("sig1: "+dict["sig1"], "wc1: "+dict["wc1"], "wc4: "+dict["wc4"], "sig(wc1+wc4): "+sig(dict["wc1"] + dict["wc4"]));
   //console.log("sig2: "+dict["sig2"], "wc2: "+dict["wc2"], "wc3: "+dict["wc3"], "sig(wc2+wc3): "+sig(dict["wc2"] + dict["wc3"]));
}

function show_dict_short(){
	console.log("1:"+dict["sq1"]+dict["sq2"]+dict["sq3"]+dict["sq4"]);
	console.log("2:"+dict["wc1"]+dict["wc2"]+dict["wc3"]+dict["wc4"]);
	console.log("3:"+dict["sig1"]+dict["sig2"]+dict["sig3"]+dict["sig4"]);
	console.log("4:"+dict["sig5"]+dict["sig6"]+dict["sig7"]+dict["sig8"]);
/*
relu1  relu2  relu3  relu4  relu5 relu6 relu7 relu8
output1 output2 output3 output4
*/
}

function set_vals(){
   //show_dict();
   if (dict["sq1"] == 1) document.getElementById("sq1").src = "wsq.svg";
   else document.getElementById("sq1").src = "bsq.svg";
   if (dict["sq2"] == 1) document.getElementById("sq2").src = "wsq.svg";
   else document.getElementById("sq2").src = "bsq.svg";
   if (dict["sq3"] == 1) document.getElementById("sq3").src = "wsq.svg";
   else document.getElementById("sq3").src = "bsq.svg";
   if (dict["sq4"] == 1) document.getElementById("sq4").src = "wsq.svg";
   else document.getElementById("sq4").src = "bsq.svg"; 
   //---
   if (dict["wc1"] == 1) document.getElementById("wc1").src = "white_circle.svg";
   else document.getElementById("wc1").src = "black_circle.svg";
   if (dict["wc2"] == 1) document.getElementById("wc2").src = "white_circle.svg";
   else document.getElementById("wc2").src = "black_circle.svg";
   if (dict["wc3"] == 1) document.getElementById("wc3").src = "white_circle.svg";
   else document.getElementById("wc3").src = "black_circle.svg";
   if (dict["wc4"] == 1) document.getElementById("wc4").src = "white_circle.svg";
   else document.getElementById("wc4").src = "black_circle.svg";
   //---
   if (dict["sig1"] == 1) document.getElementById("sig1").src = "sig_wh.svg";
   else if (dict["sig1"] == 0) document.getElementById("sig1").src = "sig_gr.svg";
   else document.getElementById("sig1").src = "sig_bl.svg";
   //-
   if (dict["sig2"] == 1) document.getElementById("sig2").src = "sig_wh.svg";
   else if (dict["sig2"] == 0) document.getElementById("sig2").src = "sig_gr.svg";
   else document.getElementById("sig2").src = "sig_bl.svg";
   //-
   if (dict["sig3"] == 1) document.getElementById("sig3").src = "sig_wh.svg";
   else if (dict["sig3"] == 0) document.getElementById("sig3").src = "sig_gr.svg";
   else document.getElementById("sig3").src = "sig_bl.svg";
   //-
   if (dict["sig4"] == 1) document.getElementById("sig4").src = "sig_wh.svg";
   else if (dict["sig4"] == 0) document.getElementById("sig4").src = "sig_gr.svg";
   else document.getElementById("sig4").src = "sig_bl.svg"; 
   //---
   if (dict["sig5"] == 1) document.getElementById("sig5").src = "sig_wh.svg";
   else if (dict["sig5"] == 0) document.getElementById("sig5").src = "sig_gr.svg";
   else document.getElementById("sig5").src = "sig_bl.svg";
   //-
   if (dict["sig6"] == 1) document.getElementById("sig6").src = "sig_wh.svg";
   else if (dict["sig6"] == 0) document.getElementById("sig6").src = "sig_gr.svg";
   else document.getElementById("sig6").src = "sig_bl.svg";
   //-
   if (dict["sig7"] == 1) document.getElementById("sig7").src = "sig_wh.svg";
   else if (dict["sig7"] == 0) document.getElementById("sig7").src = "sig_gr.svg";
   else document.getElementById("sig7").src = "sig_bl.svg";
   //-
   if (dict["sig8"] == 1) document.getElementById("sig8").src = "sig_wh.svg";
   else if (dict["sig8"] == 0) document.getElementById("sig8").src = "sig_gr.svg";
   else document.getElementById("sig8").src = "sig_bl.svg"; 
   //---
    if (dict["relu1"] == 1) document.getElementById("relu1").src = "relu_wh.svg";
    else document.getElementById("relu1").src = "relu_gr.svg";
	if (dict["relu2"] == 1) document.getElementById("relu2").src = "relu_wh.svg";
    else document.getElementById("relu2").src = "relu_gr.svg";
	if (dict["relu3"] == 1) document.getElementById("relu3").src = "relu_wh.svg";
    else document.getElementById("relu3").src = "relu_gr.svg";
    if (dict["relu4"] == 1) document.getElementById("relu4").src = "relu_wh.svg";
    else document.getElementById("relu4").src = "relu_gr.svg";
    if (dict["relu5"] == 1) document.getElementById("relu5").src = "relu_wh.svg";
    else document.getElementById("relu5").src = "relu_gr.svg";
    if (dict["relu6"] == 1) document.getElementById("relu6").src = "relu_wh.svg";
    else document.getElementById("relu6").src = "relu_gr.svg";
    if (dict["relu7"] == 1) document.getElementById("relu7").src = "relu_wh.svg";
    else document.getElementById("relu7").src = "relu_gr.svg";
    if (dict["relu8"] == 1) document.getElementById("relu8").src = 	"relu_wh.svg";
    else document.getElementById("relu8").src = "relu_gr.svg";
    //---
    if (dict["output1"] == 1) document.getElementById("output1").src = "white_circle.svg";
    else if (dict["output1"] == 0) document.getElementById("output1").src = "grey_circle.svg";
    else document.getElementById("output1").src = "black_circle.svg";
    //-
    if (dict["output2"] == 1) document.getElementById("output2").src = "white_circle.svg";
    else if (dict["output2"] == 0) document.getElementById("output2").src = "grey_circle.svg";
    else document.getElementById("output2").src = "black_circle.svg";
    //-
    if (dict["output3"] == 1) document.getElementById("output3").src = "white_circle.svg";
    else if (dict["output3"] == 0) document.getElementById("output3").src = "grey_circle.svg";
    else document.getElementById("output3").src = "black_circle.svg";
    //-
    if (dict["output4"] == 1) document.getElementById("output4").src = "white_circle.svg";
    else if (dict["output4"] == 0) document.getElementById("output4").src = "grey_circle.svg";
    else document.getElementById("output4").src = "black_circle.svg";
    //---
}

/*
sq1  wc1  sig1  sig5  relu1  output1
sq2  wc2  sig2  sig6  relu2  output2
sq3  wc3  sig3  sig7  relu3  output3
sq4  wc4  sig4  sig8  relu4  output4
                      relu5
                      relu6
                      relu7
                      relu8
*/

function show_dict(){
   for(var key in dict) {
      //var value = dict[key];
      console.log(key + " " + dict[key]);
   }
}

function change_squ_img(id) {	
    //console.log(id);
	var fname1 = document.getElementById(id).src
	var fname2 = fname1.substring(fname1.lastIndexOf('/')+1);
	if (fname2 == "wsq.svg") 
	{
		dict[id] = -1;
		document.getElementById(id).src = "bsq.svg";
	}
	else 
	{
		dict[id] = 1;
		document.getElementById(id).src = "wsq.svg";
	}
	//show_dict();
	propagate();
	set_vals();
}

function change_circle_img(id) {	
	var fname1 = document.getElementById(id).src
	var fname2 = fname1.substring(fname1.lastIndexOf('/')+1);
	if (fname2 == "white_circle.svg") 
	{
		document.getElementById(id).src = "black_circle.svg";
	}
	else 
	{
		document.getElementById(id).src = "white_circle.svg";
	}
}

function change_sig_img(id) {	
	var fname1 = document.getElementById(id).src
	var fname2 = fname1.substring(fname1.lastIndexOf('/')+1);
	if (fname2 == "sig_wh.svg") 
	{
		document.getElementById(id).src = "sig_gr.svg";
	}
	else if (fname2 == "sig_gr.svg") 
	{
		document.getElementById(id).src = "sig_bl.svg";
	}
	else
	{
		document.getElementById(id).src = "sig_wh.svg";		
	}
}

function change_relu_img(id) {	
	var fname1 = document.getElementById(id).src
	var fname2 = fname1.substring(fname1.lastIndexOf('/')+1);
	if (fname2 == "relu_wh.svg") 
	{
		document.getElementById(id).src = "relu_gr.svg";
	}
	else 
	{
		document.getElementById(id).src = "relu_wh.svg";
	}
}

function change_output_img(id) {	
	var fname1 = document.getElementById(id).src
	var fname2 = fname1.substring(fname1.lastIndexOf('/')+1);
	if (fname2 == "white_circle.svg") 
	{
		document.getElementById(id).src = "grey_circle.svg";
	}
	else 
	{
		document.getElementById(id).src = "white_circle.svg";
	}
}
