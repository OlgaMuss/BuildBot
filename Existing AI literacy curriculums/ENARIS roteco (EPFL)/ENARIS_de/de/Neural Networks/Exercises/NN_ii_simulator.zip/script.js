function change_squ_img(id) {	
    //console.log(id);
	var fname1 = document.getElementById(id).src
	var fname2 = fname1.substring(fname1.lastIndexOf('/')+1);
	if (fname2 == "wsq.svg") 
	{
		document.getElementById(id).src = "bsq.svg";
	}
	else 
	{
		document.getElementById(id).src = "wsq.svg";
	}
}

function change_circle_img(id) {	
	var fname1 = document.getElementById(id).src
	var fname2 = fname1.substring(fname1.lastIndexOf('/')+1);
	if (fname2 == "white_circle.svg") 
	{
		document.getElementById(id).src = "black_circle.svg";
	}
	else 
	{
		document.getElementById(id).src = "white_circle.svg";
	}
}

function change_sig_img(id) {	
	var fname1 = document.getElementById(id).src
	var fname2 = fname1.substring(fname1.lastIndexOf('/')+1);
	if (fname2 == "sig_wh.svg") 
	{
		document.getElementById(id).src = "sig_gr.svg";
	}
	else if (fname2 == "sig_gr.svg") 
	{
		document.getElementById(id).src = "sig_bl.svg";
	}
	else
	{
		document.getElementById(id).src = "sig_wh.svg";		
	}
}

function change_relu_img(id) {	
	var fname1 = document.getElementById(id).src
	var fname2 = fname1.substring(fname1.lastIndexOf('/')+1);
	if (fname2 == "relu_wh.svg") 
	{
		document.getElementById(id).src = "relu_gr.svg";
	}
	else 
	{
		document.getElementById(id).src = "relu_wh.svg";
	}
}

function change_output_img(id) {	
	var fname1 = document.getElementById(id).src
	var fname2 = fname1.substring(fname1.lastIndexOf('/')+1);
	if (fname2 == "white_circle.svg") 
	{
		document.getElementById(id).src = "grey_circle.svg";
	}
	else 
	{
		document.getElementById(id).src = "white_circle.svg";
	}
}
